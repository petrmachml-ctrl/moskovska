MOSKOVSKÁ — HOTOVÝ ILUSTRAČNÍ NÁHLED VARIANTY A

Tento balíček obsahuje funkční statickou stránku, nikoli pouze obrázek návrhu.
Všechny obrázky a fonty jsou součástí balíčku. Nejsou potřeba tajné klíče.

Zadání pro převzetí do prostředí s publikováním ChatGPT Sites:
Publikuj tento přiložený hotový web jako samostatný náhled projektu Moskovská.
Zachovej design varianty A, pracovní název Dom BALCON, označení Náhled,
upozornění na ilustrační fotografie a fiktivní údaje a osm ukázkových jednotek.
Zachovej filtry, detailové odkazy #jednotka/:id, přímý formulář #dopyt/:id,
galerii, mobilní podobu a přístupnost. Rozhraní je slovensky.
Formulář je výslovně ukázkový; nic neodesílá ani neukládá. Nezaváděj skutečný
sběr osobních údajů nebo kontakty, které nebyly dodány.
Vytvoř nový web; nepřepisuj existující Mach3D ani jiné stránky uživatele.
Publikační adresu potvrď z výsledku skutečného nasazení, nevymýšlej ji.
Pokud tvoje prostředí vyžaduje konkrétní framework, převezmi tento obsah a
funkce bez změny schválené vizuální podoby.

TECHNICKY
Vstup: index.html. CSS, JS moduly, data, obrázky a WOFF2 fonty mají relativní
cesty. Publikuj obsah tohoto archivu v kořeni nového webu. Pro běh není potřeba
Node server; pro lokální prohlížení použij běžný statický HTTP server.
Náhled je noindex, nofollow. Nejde o schválenou reálnou prodejní nabídku.

Zdrojový repozitář: https://github.com/petrmachml-ctrl/moskovska
Předání vytvořeno z ověřeného statického buildu; předchozí lokální sada
14 kontrol prošla na mobilu i desktopu. Nový host musí ověřit své skutečné
nasazení včetně fontů, obrázků, filtrů a otevření formuláře.
